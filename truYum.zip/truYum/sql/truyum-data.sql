CREATE DATABASE if not exists truyum;
use truyum;

CREATE TABLE if not exists menu_item(
Menu_item_id int auto_increment primary KEY,
Name varchar(100),
Price decimal(8,2),
Active varchar(20),
DateofLaunch date,
Category varchar(30),
FreeDelivery varchar(20),
Action varchar(20)
);
CREATE TABLE if not exists users(
user_id int auto_increment primary key,
user_name varchar(100)
);
CREATE TABLE if not exists Cart(
cart_id int auto_increment primary key,
user_id int,
menu_item_id int,
constraint fk foreign key(user_id) references users(user_id),
constraint fk1 foreign key(menu_item_id) references menu_item(menu_item_id)
);

INSERT INTO menu_item(Name,Price,Active,DateofLaunch,Category,FreeDelivery) VALUES("Sandwich",99.00,"Yes",'2017-03-15',"Main Course","Yes");
INSERT INTO menu_item(Name,Price,Active,DateofLaunch,Category,FreeDelivery) VALUES("Burger",129.00,"Yes",'2017-12-23',"Main Course","Yes");
INSERT INTO menu_item(Name,Price,Active,DateofLaunch,Category,FreeDelivery) VALUES("Pizza",149.00,"Yes",'2017-08-21',"Main Course","Yes");
INSERT INTO menu_item(Name,Price,Active,DateofLaunch,Category,FreeDelivery) VALUES("French Fries",57.00,"No",'2017-07-02',"Main Course","Yes");
INSERT INTO menu_item(Name,Price,Active,DateofLaunch,Category,FreeDelivery) VALUES("Chocolate Brownie",32.00,"Yes",'2022-11-02',"Main Course","Yes");

insert into users(user_name) VALUES ("Rina");
insert into users(user_name) VALUES ("Mina");

SELECT Name, CONCAT("Rs. ",Price) as Price,Active,DateofLaunch,Category,FreeDelivery 
FROM menu_item;

SELECT Name,FreeDelivery,CONCAT("Rs. ",Price) as Price,Category
from menu_item
where DateofLaunch<NOW() AND Active="Yes";

select Name, CONCAT("Rs. ",Price) as Price,Active,DateofLaunch,Category,FreeDelivery 
FROM menu_item where menu_item_id=4;

update menu_item set price=100.00
where menu_item_id=5;






insert into cart(user_id,menu_item_id) values(1,4);
insert into cart(user_id,menu_item_id) values(1,3);
insert into cart(user_id,menu_item_id) values(1,1);

select * from menu_item m
inner join cart c on m.menu_item_id=c.menu_item_id
inner join users u on c.user_id=u.user_id
where c.user_id=1;

select concat("Total Rs. ",SUM(Price)) from menu_item m
inner join cart c on m.menu_item_id=c.menu_item_id
inner join users u on c.user_id=u.user_id
where c.user_id=1;

delete from cart c
where c.user_id=1 and menu_item_id=4;











